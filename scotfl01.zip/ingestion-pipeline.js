// ---------------------------------------------------------------------------
// Multi-court ingestion engine.
//
// The core insight generalizes: state appellate courts encode the filing year
// in the docket number itself. What differs per state is the format, so each
// court gets a small adapter rather than a bespoke pipeline. Adding a court is
// a config change, not an engineering project — that is what makes coverage
// scale.
// ---------------------------------------------------------------------------

const ADAPTERS = {
  florida: {
    id: "florida",
    court: "Supreme Court of Florida",
    // SC2024-0380 -> four-digit year
    pattern: /SC(\d{4})-(\d+)/,
    filingYear: (m) => parseInt(m[1], 10),
    sequence: (m) => parseInt(m[2], 10),
    caseType: () => null, // Florida encodes no type in the docket
    sourceIndex: (year) => `https://law.justia.com/cases/florida/supreme-court/${year}/`,
  },
  georgia: {
    id: "georgia",
    court: "Supreme Court of Georgia",
    // S26A0374 -> two-digit year plus a term letter carrying case type
    pattern: /S(\d{2})([A-Z])(\d+)/,
    filingYear: (m) => 2000 + parseInt(m[1], 10),
    sequence: (m) => parseInt(m[3], 10),
    caseType: (m) => ({
      A: "Direct appeal",
      G: "Certiorari granted",
      Y: "Attorney discipline",
      D: "Discretionary application",
university: null,
    }[m[2]] || null),
    sourceIndex: (year) => `https://law.justia.com/cases/georgia/supreme-court/${year}/`,
  },
};

function parseDocket(docket, courtId) {
  const a = ADAPTERS[courtId];
  if (!a) throw new Error(`No adapter registered for court: ${courtId}`);
  const m = docket.match(a.pattern);
  if (!m) return null;
  return {
    court: a.court,
    filingYear: a.filingYear(m),
    sequence: a.sequence(m),
    caseType: a.caseType(m),
  };
}

function dispositionDays(docket, decisionDate, courtId) {
  const p = parseDocket(docket, courtId);
  if (!p) return null;
  const [y, mo, d] = decisionDate.split("-").map(Number);
  return Math.round((Date.UTC(y, mo - 1, d) - Date.UTC(p.filingYear, 0, 1)) / 86400000);
}

// Parses the Justia year-index markdown into structured records. Entries look
// like a bolded linked caption, then a Date line, then a Docket Number(s) line.
function parseJustiaIndex(markdown) {
  const out = [];
  const entry = /\[\*\*(.+?)\*\*\]\((https:\/\/law\.justia\.com\/cases\/[^)]+)\)\s+\*\*Date:\*\*\s*([A-Za-z]+ \d{1,2}, \d{4})\s+\*\*Docket Numbers?:\*\*\s*([^\n]+)/g;
  const MONTHS = { January: 1, February: 2, March: 3, April: 4, May: 5, June: 6, July: 7, August: 8, September: 9, October: 10, November: 11, December: 12 };
  let m;
  while ((m = entry.exec(markdown)) !== null) {
    const [, title, url, dateStr, docketStr] = m;
    const dm = dateStr.match(/([A-Za-z]+) (\d{1,2}), (\d{4})/);
    if (!dm) continue;
    const iso = `${dm[3]}-${String(MONTHS[dm[1]]).padStart(2, "0")}-${String(dm[2]).padStart(2, "0")}`;
    const dockets = docketStr.split(",").map((s) => s.trim()).filter(Boolean);
    out.push({ title: title.trim(), url, date: iso, docket: dockets.join(" · ") });
  }
  return out;
}

// Same matter can appear twice when a substitute opinion issues. Keep the
// later decision and flag the supersession rather than silently dropping it.
function dedupe(records) {
  const byKey = new Map();
  const superseded = [];
  records.forEach((r) => {
    const key = `${r.docket}|${r.title}`;
    const prior = byKey.get(key);
    if (!prior) { byKey.set(key, r); return; }
    const [keep, drop] = r.date > prior.date ? [r, prior] : [prior, r];
    byKey.set(key, keep);
    superseded.push(drop);
  });
  return { records: [...byKey.values()], superseded };
}

module.exports = { ADAPTERS, parseDocket, dispositionDays, parseJustiaIndex, dedupe };
