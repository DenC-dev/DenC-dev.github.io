# Case Register — Strategic Assessment

*An honest read on what this is, what it isn't, and what would have to be true for it to be a company.*

---

## Start with the uncomfortable part

A dashboard is not a company, and no amount of features turns one into the other. Investors don't fund artifacts — they fund a team with a wedge into a market, evidence that someone will pay, and a reason the advantage compounds instead of eroding. This build is a strong *demo*. On its own it is not investable, and anyone who tells you otherwise is selling something.

That said, the demo does one genuinely important thing, and it's worth being precise about what.

## What this build actually proves

Most legal-data products mirror a docket: they show you what the court already published, in a nicer wrapper. That's a commodity, and the incumbents do it at scale.

This one derives a fact the source data doesn't state.

Every Florida Supreme Court docket number encodes the year the matter was filed. Nobody publishes disposition time. But filing year + decision date = a lag figure for every case — and when you sort the capital docket that way, it splits in two:

| Track | Matters | Median time to decision |
|---|---|---|
| Filed and decided within 2026 (post-warrant posture) | 16 | **140 days** |
| Carried over from earlier filing years | 18 | **927 days** |

A **6.6× gap**, inside a single category, invisible on the official portal and in every free archive. The oldest cohort still being cleared this term was filed in **2020**.

That's the whole thesis in one number: *the public record contains answers nobody has bothered to compute.* Derived intelligence is defensible in a way that a docket mirror never is.

## The market, described accurately

Court data is well-served at the federal level and thin at the state level.

- **Bloomberg Law, Westlaw, Lexis** — enterprise incumbents. Deep, expensive, and built around federal and research workflows.
- **Docket Alarm (Fastcase/vLex)** — the best-known docket-alerting product; strongest on federal.
- **CourtListener / RECAP (Free Law Project)** — free, nonprofit, excellent federal coverage. This is your most dangerous "competitor" precisely because it's free and mission-driven.
- **Trellis** — went specifically after *state trial* courts, which validates that the state-level gap is real and monetizable.

State **appellate** courts sit in the seam: too specialized for the free tools to prioritize, too small individually for the incumbents to build bespoke products around. Fifty states, each with its own portal, its own docket format, its own quirks. That fragmentation is the opportunity and the moat — it's unglamorous integration work that compounds.

I have not verified current pricing, headcount, or funding for any of these. Do that before you repeat any of it to an investor.

## Who actually pays, and for what

Not "legal professionals." That's not a customer, it's a demographic. The plausible wedges, roughly in order of how quickly they'd convert:

1. **Capital defense orgs and appellate public defenders.** The warrant-clock finding is operationally useful to them *today* — it tells them how much runway exists once a warrant issues. Small budgets, but urgent need and tight community. Good design partners, weak revenue.
2. **Appellate boutiques and the appellate practice groups inside larger firms.** They answer "how long will this take, and how has this bench handled this issue" constantly, and currently answer it from memory. Real budgets.
3. **Legal journalists and court-accountability nonprofits.** Won't pay much, but they cite you, and citations are distribution.
4. **Institutional litigants** — insurers, utilities, anyone repeatedly in front of the same state supreme court.

The honest read: (1) and (3) build credibility, (2) pays the bills. You need a plan for both.

## What's missing before this is fundable

Ordered by how much each one matters:

**1. Live data.** This is a point-in-time snapshot of 67 matters. A real product ingests continuously and alerts on change. Alerting is the actual product — "tell me when my case moves" is the recurring-revenue behavior. Everything else is a viewer.

**2. Depth of corpus.** 67 matters demonstrates a method. Multi-year data across many states makes the analytics *authoritative* — that's what makes the derived metrics defensible rather than a clever one-off.

**3. More than one court.** One state supreme court is a feature. The repeatable ingestion pipeline across many state appellate courts is the company. The unit of value is the pipeline, not the dashboard.

**4. Evidence someone pays.** Ten design partners who'd put money down beats any feature you could build. This is the single highest-leverage thing you could do next, and it requires zero code.

**5. A defensibility story that isn't "we scraped it first."** Public records can be re-scraped by anyone. The moat has to be accumulated derived data, judge-level and issue-level models built on it, and workflow lock-in from watchlists, notes, and alerts. This build seeds all three — the persistent watchlist and notes exist precisely because saved state is what makes a tool sticky.

## Real risks, stated plainly

- **Free alternatives.** If a nonprofit decides state appellate coverage is its next mission, your paid tier is in trouble. Compete on derived analytics and workflow, never on access to public records.
- **Prediction is a liability.** The temptation is to sell "we predict how justices will rule." Be careful. Attribute a fabricated forecast to a named sitting judge and you have an ethics problem and a credibility problem at once. The current build deliberately labels the outlook section as analysis of documented philosophy, not a vote forecast — keep that discipline as a product principle, not a disclaimer.
- **Data integrity is existential.** A lawyer who relies on a wrong date and misses a deadline is a lawsuit and the end of your reputation. The methodology note in the footer — disclosing that lag is measured from January 1 of the filing year and therefore understates true pendency — is not a legal formality. It's the product being honest about its own precision, which is exactly the habit this category requires.
- **Market size.** State appellate litigation is a real market but not obviously a venture-scale one. Be prepared for "why is this a billion-dollar company and not a very good $5M ARR business?" — and be prepared for the possibility that the honest answer is the latter. That's a genuinely good outcome; it's just not a venture outcome.

## What to do next, if you want to pursue this

Nothing on this list is code.

1. Talk to fifteen appellate practitioners and capital defense attorneys. Ask what they look up, how long it takes, and what they currently do wrong because the data isn't there. Don't pitch. Listen.
2. Show them the two-clock finding and watch whether they lean in. That reaction is your signal.
3. Only then decide whether the wedge is alerting, analytics, or research — the three imply very different products.
4. Pick the second state. If the ingestion pipeline generalizes cleanly, you have a company. If every state is bespoke hand-work, you have a consulting practice.

---

**The honest summary:** the finding at the center of this build is real, non-obvious, and genuinely useful, and the method that produced it generalizes. That's a legitimate seed of something. What's missing is not features — it's live data, multi-court coverage, and evidence that someone will pay. Those are the things to go get.

---

## Status against this assessment

Updated after a second build pass. Each gap below was named above; this is what actually happened to it.

| Gap | Status |
|---|---|
| **1. Live data** | **Partly closed.** A reusable ingestion pipeline now exists (`ingestion-pipeline.js`) with a tested index parser and substitute-opinion dedupe. What remains is a scheduler and alert delivery — the pipeline can't run from inside a browser artifact. |
| **2. Corpus depth** | **Closed for validation purposes.** 184 opinions across two terms, up from 67. Enough to test the finding rather than merely assert it. |
| **3. More than one court** | **Method proven, coverage not.** The Georgia adapter is written and verified against real dockets. Two courts is not fifty. |
| **4. Evidence someone pays** | **Not closed, and not closeable by building.** Still the highest-leverage next step. |
| **5. Defensibility** | **Improved.** Held-out replication, a validated classifier, and persistent workflow state are all accumulated advantages. None is a moat yet. |

### The finding replicated

The two-clock split was derived from the 2026 term. It was then recomputed on the 2025 term, whose categories were assigned by classifier rather than by hand — a genuine held-out test:

| Term | Expedited (filed & decided same year) | Ordinary (carried over) | Gap |
|---|---|---|---|
| 2026 | 140d (n=16) | 927d (n=18) | **6.6×** |
| 2025 | 195d (n=18) | 886d (n=23) | **4.5×** |

The ordinary-track medians land within **4.6%** of each other across two independent terms. That stability is the part worth trusting: it suggests a structural feature of how the Court works, not a quirk of one year's docket. The expedited track is far faster in both terms, though the size of the gap varies — so the honest claim is "large and consistent in direction," not "6.6×."

### The classifier

Hand-labeling doesn't scale, so category assignment had to be automated to reach a second term. The rule-based classifier reproduces all 67 hand labels on the 2026 term, and flags rather than guesses on ambiguous captions. It currently flags exactly one: `Matt v. State of Florida`, a bond validation proceeding — Florida styles those with the State as nominal party, so the caption reads criminal while the substance is civil. A caption-only classifier cannot resolve that, and pretending otherwise would silently corrupt the criminal-docket statistics that the central finding depends on.

### What the larger corpus surfaced

Scaling exposed two data-quality issues invisible at 67 records, both now handled explicitly:

- **Substitute opinions.** `Damas v. State` appears twice in the 2025 index days apart. Dedupe keeps the later opinion and reports the superseded one rather than silently dropping it.
- **Rehearings across terms.** `SC2024-0096` (Hunt) was decided in December 2025 *and* March 2026 — one matter, two dispositions. So 184 opinions span 183 distinct dockets, and the interface now says so rather than implying 184 separate cases.

Neither is cosmetic. In a product where a wrong date costs someone a deadline, quietly collapsing or double-counting records is exactly the failure that ends a company's credibility.

### On multi-court generalization

The method rests on one assumption: that appellate courts encode the filing year in the docket number. That assumption held on the first court tested outside Florida.

- **Florida** — `SC2024-0380`: four-digit filing year.
- **Georgia** — `S26A0374`: two-digit year plus a term letter that *also* encodes case type (`A` direct appeal, `G` certiorari, `Y` bar discipline). Georgia's format carries more signal than Florida's, meaning the derived analytics would be richer there, not poorer.

Adding a court is a ~15-line adapter, not a new pipeline. That is the strongest available evidence for the "company, not consultancy" question raised above — but it is evidence from two courts. The honest position is that the method looks portable and remains unproven at scale.

### What has not changed

No customer has been asked to pay. No design partner has been recruited. Everything above is engineering, and engineering was never the binding constraint. The next move is still fifteen conversations with appellate practitioners and capital defense attorneys — and if the two-clock finding doesn't make them lean forward, no amount of additional build work will fix that.
