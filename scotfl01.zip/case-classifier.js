// Classifies a matter from its caption, optionally disambiguated by summary
// text. This is the component that makes multi-year, multi-court ingestion
// possible: hand-labeling does not scale, so these rules must reproduce human
// labels reliably enough to trust on unseen years.
//
// Order matters — rules run most-specific first.

const CIVIL_SIGNALS = /\b(bond|bonds|district|contract|breach|insurance|insurer|negligence|premises|foreclosure|dissolution|marital|probate|utility|rate plan|easement|zoning|tort|damages|employment|terminated|wrongful)\b/;
const CRIMINAL_SIGNALS = /\b(murder|homicide|conviction|convicted|sentence|sentenced|death penalty|postconviction|habeas|capital|robbery|battery|kidnap|felony|defendant|prosecut|dna testing|death warrant|lethal injection)\b/;

function classify(title, summary) {
  const t = title.toLowerCase();
  const s = (summary || "").toLowerCase();

  if (/^in re:?\s*amendment/.test(t)) return "Rules & Administration";
  if (/^in re:?\s*.*\brules?\b/.test(t)) return "Rules & Administration";

  if (/inquiry concerning a judge/.test(t)) return "Judicial Conduct & Petitions";
  if (/\bjqc\b/.test(t)) return "Judicial Conduct & Petitions";
  if (/v\.\s*(chief\s+)?judge\b/.test(t)) return "Judicial Conduct & Petitions";

  if (/^(the\s+)?florida bar v\./.test(t)) return "Attorney Discipline";
  if (/v\.\s*(the\s+)?florida bar\b/.test(t)) return "Attorney Discipline";
  if (/^in re:?\s*(the\s+)?florida bar/.test(t)) return "Attorney Discipline";

  // Handles both "Department" and the abbreviated "Dept." caption form.
  if (/secretary,?\s*(of\s*)?(the\s*)?florida\s+dep(artmen)?t\.?\s*of\s*state/.test(t)) return "Elections & Public Bodies";
  if (/\b(canvassing board|division of elections|supervisor of elections)\b/.test(t)) return "Elections & Public Bodies";

  // Florida styles bond validation proceedings as "X v. State of Florida" with
  // the State as nominal party, so a criminal caption alone is not decisive.
  const criminalCaption = /\bv\.\s*state\b/.test(t) || /^state (of florida )?v\./.test(t) ||
    /v\.\s*secretary,?\s*(florida\s*)?department of corrections/.test(t);

  if (criminalCaption) {
    if (s && CIVIL_SIGNALS.test(s) && !CRIMINAL_SIGNALS.test(s)) return "Civil";
    return "Criminal & Capital";
  }

  return "Civil";
}

// Review queue: matters whose caption and substance disagree, or which fall
// through with no summary to corroborate, are what a human should check first.
function needsReview(title, summary) {
  const t = title.toLowerCase();
  const s = (summary || "").toLowerCase();
  const criminalCaption = /\bv\.\s*state\b/.test(t) || /^state (of florida )?v\./.test(t);
  if (criminalCaption && s && CIVIL_SIGNALS.test(s)) return true;
  if (!summary) return classify(title, summary) === "Civil";
  return false;
}

module.exports = { classify, needsReview };
